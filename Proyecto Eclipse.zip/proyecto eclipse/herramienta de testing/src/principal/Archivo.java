package principal;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

public class Archivo {
	
//	INICIO ATRIBUTOS
	private String nombreArchivo;
	private ArrayList<String> codigo;
	private ArrayList<Funcion> listaFunciones;
//	FIN ATRIBUTOS
	
	
//	INICIO CONSTRUCTOR
	public Archivo(File archivo){
		
		nombreArchivo = archivo.getName();
		codigo = new ArrayList<String>();
		leerLineasDeCodigo(archivo.getPath());
		procesarFunciones();
	}
//	FIN CONSTRUCTOR
	
	
//	INICIO METODOS
	public String getNombreArchivo(){
		
		return nombreArchivo;
		
	}
	
	private void leerLineasDeCodigo(String path) {
		
		FileReader fr = null;
		BufferedReader br = null;
		String linea = null;
		
		try {
			
			fr = new FileReader(path);
			br = new BufferedReader(fr);

			while ((linea = br.readLine()) != null) {
				codigo.add(linea);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	private void procesarFunciones() {
		
		listaFunciones = new ArrayList<Funcion>();
		Boolean leerFuncion = false;
		Integer llavesAbiertas = 0;
		Integer llavesCerradas = 0;
		Funcion funcion = null;
		
		for (String linea : codigo) {
			
			String lineaTrimeada = linea.trim();
			
			if (lineaTrimeada.startsWith("public") || lineaTrimeada.startsWith("private ") || lineaTrimeada.startsWith("protected ") && lineaTrimeada.contains("(") && lineaTrimeada.contains(")")) {
				
				String palabraAnterior = "";
				
				for (String palabra : lineaTrimeada.split(" ")) {
					
					palabra = palabra.trim();

					if (palabra.contains("(")) {
						
						String nombreFuncion = palabra.substring(0, palabra.indexOf("("));
						if(!nombreFuncion.isEmpty())
							funcion = new Funcion(nombreFuncion);
						else
							funcion = new Funcion(palabraAnterior);
						
						leerFuncion = true;
						
						break;
					}
					
					palabraAnterior = palabra;
				}
				

			}
			
			if (leerFuncion) {
				if (lineaTrimeada.contains("{")) {
					llavesAbiertas++;
				}
				if (lineaTrimeada.contains("}")) {
					llavesCerradas++;
				}

				funcion.addCodigo(linea);
				
				if (llavesAbiertas == llavesCerradas) {
					leerFuncion = false;
					listaFunciones.add(funcion);
				}
			}

		}
		
	}
	
	public ArrayList<Funcion> getListaFunciones(){
		return listaFunciones;
	}
//	FIN METODOS
}
