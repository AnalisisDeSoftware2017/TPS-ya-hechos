package principal;

import java.util.ArrayList;
import java.util.Arrays;

public class Halstead {
	
	private Integer N1;	// Operadores.
	private Integer n1;	// Operadores unicos.
	private Integer N2;	// Operandos.
	private Integer n2;	// Operandos unicos.
	
	private ArrayList<String> listaOperadores = new ArrayList<String>(Arrays.asList(	"++","--","==","<=",">=","!=","&&","||",
																				"+","-","=","<",">","!",
																				"*", "/", "%", "^",
																				";", "{",
																				"for","while","if","switch","println"
																				));
	private ArrayList<String> condicionOperandos = new ArrayList<String>(Arrays.asList("Integer","int","Float","float", "Double", "double","String","Boolean","bool", "ArrayList<String>",  "ArrayList<Funcion>"));
	
	public Halstead(ArrayList<String> codigo){
		calculoOperadores(codigo);
		calculoOperandos(codigo);
	}
	
	public Integer getN1(){
		return N1;
	}
	
	public Integer getn1(){
		return n1;
	}
	
	public Integer getN2(){
		return N2;
	}
	
	public Integer getn2(){
		return n2;
	}
	
	public Integer getLongitud(){
		return N1 + N2;
	}
	
	public Double getVolumen(){
		return getLongitud() * ( Math.log10(n1 + n2)/Math.log10(2) );
	}

	private void calculoOperadores(ArrayList<String> codigo){
		
		ArrayList<String> operadores = new ArrayList<String>();
		ArrayList<String> operadoresUnicos = new ArrayList<String>();
		
		for(String linea : codigo){
			
			if (linea.contains("//")){
				linea = linea.substring(0, linea.indexOf("//"));
			}
			
			for(String operador : listaOperadores ){
				if(linea.contains(operador)){
					if( !(operador.equals("<") && linea.contains("new") || linea.contains("ArrayList") && linea.contains(">")) && !(operador.equals(">") && linea.contains("new") || linea.contains("ArrayList") && linea.contains("<")) ){
						operadores.add(operador);
					}
				}
			}
		}
		
		for(String operador : operadores){
			if(!operadoresUnicos.contains(operador)){
				operadoresUnicos.add(operador);
			}
		}
		
		N1 = operadores.size();
		n1 = operadoresUnicos.size();
		
	}
	
	private void calculoOperandos(ArrayList<String> codigo){
		
		ArrayList<String> listaOperandos = new ArrayList<String>();
		ArrayList<String> operandosEnCodigo = new ArrayList<String>();
		ArrayList<String> operandosUnicosEnCodigo = new ArrayList<String>();
		
		for(String linea : codigo){
			
			if (linea.contains("//")){
				linea = linea.substring(0, linea.indexOf("//"));
			}
			
			String[] palabras = linea.split(" ");
			
			Boolean proximaPalabra = false;
			
			for(String palabra : palabras){
				
				palabra = palabra.trim();
				
				if(proximaPalabra){
					proximaPalabra = false;
					
					if(palabra.endsWith(";") || palabra.endsWith("=")){
						palabra = palabra.substring(0, palabra.length()-1);
					}
					listaOperandos.add(palabra);
				}
				
				if(condicionOperandos.contains(palabra)){
					proximaPalabra = true;
				}
			}

		}
	

		for(String linea : codigo){
			
			if (linea.contains("//")){
				linea = linea.substring(0, linea.indexOf("//"));
			}
			
			for(String operando : listaOperandos){
				if(linea.contains(operando)){
					operandosEnCodigo.add(operando);
					if(!operandosUnicosEnCodigo.contains(operando)){
						operandosUnicosEnCodigo.add(operando);
					}
				}
				
			}
		}
		
		N2 = operandosEnCodigo.size();
		n2 = operandosUnicosEnCodigo.size();
	}
}
