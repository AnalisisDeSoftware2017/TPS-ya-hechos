package principal;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Funcion {

//	INICIO ATRIBUTOS
	private String nombre;
	private ArrayList<String> codigo;
	private Integer cantidadLineasCodigo;
	private Integer porcentajeComentarios;
	private Integer fanIn;
	private Integer fanOut;
	private Integer complejidadCiclomatica;
//	FIN ATRIBUTOS
	

// INICIO CONSTRUCTOR
	public Funcion(String nombre) {
		this.nombre = nombre;
		codigo = new ArrayList<String>();
	}
//	FIN CONSTRUCTOR

	
//	INICIO METODOS
	public String getNombre() {
		return nombre;
	}

	public ArrayList<String> getCodigo() {
		return codigo;
	}

	public void addCodigo(String linea) {
		codigo.add(linea);
	}

	public Integer getCantidadLineasDeCodigo() {
		return cantidadLineasCodigo;
	}

	private void setCantidadLineasDeCodigo() {
		int contador = 0;
		for (int i = 0; i < codigo.size(); i++) {
			String linea = codigo.get(i).trim();
			if (!linea.isEmpty())
				contador++;
		}
		cantidadLineasCodigo = contador;
	}

	public Integer getPorcentajeComentarios() {
		return porcentajeComentarios;
	}

	private void setPorcentajeComentarios() {
		
		Integer lineasComentadas = 0;

		for(String linea : codigo){
			
			if(linea.contains("//"))
				lineasComentadas++;

		}

		porcentajeComentarios = Math.round((float) 100 * lineasComentadas / cantidadLineasCodigo);
	}

	public Integer getFanIn() {
		return fanIn;
	}

	private void setFanIn(ArrayList<Funcion> funciones) {
		// Fan in: cantidad de veces que una funcion llama a otras funciones
		Set<Funcion> funcionesNoRepetidas = new HashSet<Funcion>(funciones);
		
		int contador = 0;
		for (String linea : codigo) {
			for (Funcion funcion : funcionesNoRepetidas) {
				if (linea.contains(funcion.getNombre() + "(")) {
					contador++;
				}
			}
		}
		this.fanIn = contador - 1;
	}

	public Integer getFanOut() {
		return fanOut;
	}

	private void setFanOut(ArrayList<Funcion> funciones) {
		Set<Funcion> funcionesNoRepetidas = new HashSet<Funcion>(funciones);
		// Fan out: cantidad de veces que una funcion es llamada, en todo el grupo de funciones
		int contador = 0;
		
		for (Funcion funcion : funcionesNoRepetidas) {
			for (String linea : funcion.getCodigo()) {
				if (linea.contains(nombre + "("))
					contador++;
			}
		}

		this.fanOut = contador - 1;
	}

	public Integer getComplejidadCiclomatica() {
		return complejidadCiclomatica;
	}

	private void setComplejidadCiclomatica() {
		
		int cantNodos = 0;
		int lastIndex;
		int count;

		for (String linea : codigo) {
			
			
			if (linea.contains("//")){
				linea = linea.substring(0, linea.indexOf("//"));
			}

			linea = linea.trim();
			
			if (linea.startsWith("if") || linea.startsWith("for")  || linea.startsWith("while")){
				
				cantNodos++;
				
				lastIndex = 0;
				count = 0;

				while(lastIndex != -1){

				    lastIndex = linea.indexOf("||",lastIndex);

				    if(lastIndex != -1){
				        count++;
				        lastIndex += "||".length();
				    }
				}
				cantNodos += count;
				
				lastIndex = 0;
				count = 0;
				while(lastIndex != -1){

				    lastIndex = linea.indexOf("&&",lastIndex);

				    if(lastIndex != -1){
				        count++;
				        lastIndex += "&&".length();
				    }
				}
				
				cantNodos += count;

			}
			
		}
		this.complejidadCiclomatica = cantNodos + 1;

	}

	public void procesarFuncion(ArrayList<Funcion> funciones) {
		setCantidadLineasDeCodigo();
		setPorcentajeComentarios();
		setFanIn(funciones);
		setFanOut(funciones);
		setComplejidadCiclomatica();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((nombre == null) ? 0 : nombre.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Funcion other = (Funcion) obj;
		if (nombre == null) {
			if (other.nombre != null)
				return false;
		} else if (!nombre.equals(other.nombre))
			return false;
		return true;
	}
//	FIN METODOS
}
