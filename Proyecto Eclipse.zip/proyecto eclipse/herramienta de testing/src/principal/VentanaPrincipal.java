package principal;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JSeparator;
import javax.swing.JTextArea;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

@SuppressWarnings({ "rawtypes", "unchecked", "serial" })
public class VentanaPrincipal extends JFrame implements ActionListener {

//	INICIO ATRIBUTOS
	private ArrayList<Funcion> listaFunciones;
	
	private JPanel contentPane;
	private JFileChooser fileChooser;
	private JButton btnSeleccionarArchivo;
	private JComboBox<String> ComboBoxListadoMetodos;
	private JTextArea txtCodigo;
	private JTextField txtNombreArchivo;
	private JTextField txtLineasDeCodigo;
	private JTextField txtPorcentajeComentarios;
	private JTextField txtFanIn;
	private JTextField txtFanOut;
	private JTextField txtComplejidadCiclomatica;
	private JLabel lblLongitud;
	private JTextField txtLongitud;
	private JLabel lblVolumen;
	private JTextField txtVolumen;
//	FIN ATRIBUTOS
	

//	INICIO MAIN
	public static void main(String[] args) {
		
		new VentanaPrincipal();
		
	}
//	FIN MAIN

	
//	INICIO CONSTRUCTOR
	public VentanaPrincipal() {
		setResizable(false);
		setTitle("Grupo 8");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 797, 542);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);

		fileChooser = new JFileChooser("./");
		btnSeleccionarArchivo = new JButton("Seleccionar archivo");
		btnSeleccionarArchivo.setBounds(10, 5, 157, 23);
		btnSeleccionarArchivo.addActionListener(this);
		contentPane.setLayout(null);
		contentPane.add(btnSeleccionarArchivo);
		
		ComboBoxListadoMetodos = new JComboBox();
		ComboBoxListadoMetodos.setBounds(588, 5, 144, 23);
		ComboBoxListadoMetodos.addActionListener(this);
		contentPane.add(ComboBoxListadoMetodos);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 181, 771, 322);
		contentPane.add(scrollPane);
		
		txtCodigo = new JTextArea();
		txtCodigo.setEditable(false);
		scrollPane.setViewportView(txtCodigo);
		
		JLabel lblNombreDeArchivo = new JLabel("Nombre de archivo:");
		lblNombreDeArchivo.setBounds(177, 9, 114, 14);
		contentPane.add(lblNombreDeArchivo);
		
		txtNombreArchivo = new JTextField();
		txtNombreArchivo.setEditable(false);
		txtNombreArchivo.setBounds(301, 6, 123, 20);
		contentPane.add(txtNombreArchivo);
		txtNombreArchivo.setColumns(10);
		
		JLabel lblFuncion = new JLabel("Funcion:");
		lblFuncion.setBounds(467, 9, 86, 14);
		contentPane.add(lblFuncion);
		
		JLabel lblLineasDeCodigo = new JLabel("Lineas de codigo:");
		lblLineasDeCodigo.setBounds(13, 45, 103, 14);
		contentPane.add(lblLineasDeCodigo);
		
		JLabel lblPorcentajeComentarios = new JLabel("Porcentaje de comentarios:");
		lblPorcentajeComentarios.setBounds(10, 81, 167, 14);
		contentPane.add(lblPorcentajeComentarios);
		
		JLabel lblFanIn = new JLabel("Fan In:");
		lblFanIn.setBounds(10, 119, 144, 14);
		contentPane.add(lblFanIn);
		
		JLabel lblFanOut = new JLabel("Fan Out:");
		lblFanOut.setBounds(10, 156, 144, 14);
		contentPane.add(lblFanOut);
		
		JLabel lblComplejidadCiclomatica = new JLabel("Complejidad ciclomatica:");
		lblComplejidadCiclomatica.setBounds(311, 39, 144, 14);
		contentPane.add(lblComplejidadCiclomatica);
		
		txtLineasDeCodigo = new JTextField();
		txtLineasDeCodigo.setEditable(false);
		txtLineasDeCodigo.setBounds(141, 42, 86, 20);
		contentPane.add(txtLineasDeCodigo);
		txtLineasDeCodigo.setColumns(10);
		
		txtPorcentajeComentarios = new JTextField();
		txtPorcentajeComentarios.setEditable(false);
		txtPorcentajeComentarios.setBounds(199, 78, 86, 20);
		contentPane.add(txtPorcentajeComentarios);
		txtPorcentajeComentarios.setColumns(10);
		
		txtFanIn = new JTextField();
		txtFanIn.setEditable(false);
		txtFanIn.setBounds(81, 116, 86, 20);
		contentPane.add(txtFanIn);
		txtFanIn.setColumns(10);
		
		txtFanOut = new JTextField();
		txtFanOut.setEditable(false);
		txtFanOut.setBounds(81, 153, 86, 20);
		contentPane.add(txtFanOut);
		txtFanOut.setColumns(10);
		
		txtComplejidadCiclomatica = new JTextField();
		txtComplejidadCiclomatica.setEditable(false);
		txtComplejidadCiclomatica.setBounds(481, 37, 86, 20);
		contentPane.add(txtComplejidadCiclomatica);
		txtComplejidadCiclomatica.setColumns(10);
		
		lblLongitud = new JLabel("Longitud:");
		lblLongitud.setBounds(314, 75, 103, 14);
		contentPane.add(lblLongitud);
		
		txtLongitud = new JTextField();
		txtLongitud.setEditable(false);
		txtLongitud.setColumns(10);
		txtLongitud.setBounds(442, 72, 86, 20);
		contentPane.add(txtLongitud);
		
		lblVolumen = new JLabel("Volumen:");
		lblVolumen.setBounds(314, 103, 103, 14);
		contentPane.add(lblVolumen);
		
		txtVolumen = new JTextField();
		txtVolumen.setEditable(false);
		txtVolumen.setColumns(10);
		txtVolumen.setBounds(442, 100, 86, 20);
		contentPane.add(txtVolumen);
		
		JSeparator separator_1 = new JSeparator();
		separator_1.setOrientation(SwingConstants.VERTICAL);
		separator_1.setBounds(301, 62, 32, 108);
		contentPane.add(separator_1);
		
		this.setVisible(true);
		
	}
//	FIN CONSTRUCTOR
	
	
//	INICIO METODOS
	@Override
	public void actionPerformed(ActionEvent action) {
		
		if (action.getSource() == btnSeleccionarArchivo && fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
				
			Archivo codigoFuente = new Archivo(fileChooser.getSelectedFile());

			txtNombreArchivo.setText(codigoFuente.getNombreArchivo());
			txtLineasDeCodigo.setText("");
			txtPorcentajeComentarios.setText("");
			txtFanIn.setText("");
			txtFanOut.setText("");
			txtComplejidadCiclomatica.setText("");
			txtCodigo.setText("");
			
			txtLongitud.setText("");
			txtVolumen.setText("");
			listaFunciones = codigoFuente.getListaFunciones();
			
			ComboBoxListadoMetodos.removeAllItems();
			for (Funcion funcion : listaFunciones) {
				ComboBoxListadoMetodos.addItem(funcion.getNombre());
			}
				
		}
		
		if (action.getSource() == ComboBoxListadoMetodos && ComboBoxListadoMetodos.getItemCount()!=0) {
				
				Funcion funcionSeleccionada = listaFunciones.get(ComboBoxListadoMetodos.getSelectedIndex());

				funcionSeleccionada.procesarFuncion(listaFunciones);
				
				// McCabe.
				txtLineasDeCodigo.setText(funcionSeleccionada.getCantidadLineasDeCodigo().toString());
				txtPorcentajeComentarios.setText(funcionSeleccionada.getPorcentajeComentarios().toString() + "%");
				txtFanIn.setText(funcionSeleccionada.getFanIn().toString());
				txtFanOut.setText(funcionSeleccionada.getFanOut().toString());
				txtComplejidadCiclomatica.setText(funcionSeleccionada.getComplejidadCiclomatica().toString());
				
				// Halstead.
				Halstead hal = new Halstead(funcionSeleccionada.getCodigo());
				txtLongitud.setText(hal.getLongitud().toString());
				txtVolumen.setText(String.format("%.2f", hal.getVolumen()));
				
				txtCodigo.setText("");
				for (String linea : funcionSeleccionada.getCodigo()) {
					txtCodigo.append(linea + "\n");
				}

		}

	}
}